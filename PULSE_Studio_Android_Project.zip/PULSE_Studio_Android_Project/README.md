# PULSE Studio (V1) — تطبيق مونتاج أندرويد بواجهة حركية مبتكرة

## خطوات استخراج ملف الـ APK من جوالك عبر GitHub (بدون كمبيوتر)

1. فك الضغط عن الملف `PULSE_Studio_Android_Project.zip` على جوالك.
2. افتح حسابك في [GitHub](https://github.com) من متصفح كروم (يفضّل تفعيل خيار **الموقع الإلكتروني المخصص للكمبيوتر / Desktop site** من قائمة كروم).
3. أنشئ مستودعاً جديداً (New Repository) باسم `pulse-studio` (اجعله Public أو Private).
4. اضغط **uploading an existing file** وارفع ملفات المشروع (`pubspec.yaml` ومجلد `lib` ومجلد `.github`).
   - **ملاحظة مهمة:** إذا لم يظهر مجلد `.github` في مدير ملفات جوالك لأنه يبدأ بنقطة، اضغط داخل GitHub على **Add file → Create new file**، واكتب في خانة الاسم: `.github/workflows/build_apk.yml` ثم انسخ محتوى ملف `build_apk.yml` والصقه هناك واضغط **Commit changes**.
5. افتح تبويب **Actions** في أعلى المشروع: ستجد عملية البناء تعمل تلقائياً (تستغرق 4–6 دقائق).
6. بعد ظهور علامة الصح الخضراء ✅، اضغط على العملية، ثم انزل لقسم **Artifacts** واضغط على `PULSE-Studio-Android-APK` لتحميل التطبيق وتثبيت ملف `app-arm64-v8a-release.apk` على جوالك!
